<?php

$conn = mysqli_connect("localhost", "root", "", "successcamp") or die("Cannot connect to Database");
?>