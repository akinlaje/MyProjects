<div class="container-fluid" style="background-color:#e3f2fd;">
		<div style="text-align:center">
			&copy; 2020 <a style='color:' href="https://davakconsult.com.ng">Davak Consult</a>  For DLBC Wukari Region
		</div>
	</div>