<?php
include'connection.php';
include 'secure.php';
?>
<html>
<head>
		<link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../style4.css">

    <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
</head>
<?php
include ('connection.php');
// Include user session
// include "session.php";

	if (isset($_POST['sreg'])) {
  $firstname = sec($_POST['firstname']);
  $lastname = sec($_POST['lastname']);
  $gender = sec($_POST['gender']);
  $department = sec($_POST['department']);
  $level = sec($_POST['level']);
  $section = sec($_POST['section']);
  $denomination = sec($_POST['denomination']);
  $Region = sec($_POST['Region']);
  $Rgroup = sec($_POST['Rgroup']);
  $District = sec($_POST['District']);
  $school = sec($_POST['school']);
  $phnumber = sec($_POST['phnumber']);

	// Test for duplicate entry
	$sql = "SELECT * FROM sregister WHERE firstname = '$_POST[firstname]' && lastname = '$_POST[lastname]'";
	$result = mysqli_query($conn, $sql);
	

	if(mysqli_num_rows($result) > 0)
    
{

	echo "<script>
				alert('$firstname $lastname has already registered');
				window.location.href='register.php';
				</script>";

 }
 else{
		 $sreg1 = mysqli_query($conn, "INSERT INTO sregister(firstname, lastname, gender, department, level, section, denomination, Region, Rgroup, District, school, phnumber) VALUES('$firstname', '$lastname', '$gender', '$department', '$level', '$section', '$denomination', '$Region', '$Rgroup', '$District', '$school', '$phnumber' )");

	if ($result) {
   // Javascript alert with php and redirect to another page
	    	echo "<script>
				alert('Registration successfull');
				window.location.href='register.php';
				</script>";
    
    }//end then
    else {
    echo "<b>ERROR: unable to post.</b>";
    }//end else
};
}

function sec($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
};

?>
</html>