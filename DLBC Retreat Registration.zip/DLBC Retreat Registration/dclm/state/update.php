<?php
include "connection.php";
include 'secure.php';
	if (isset($_POST['update'])) {
		$id = $_POST["id"];
	    $firstname = $_POST["firstname"];
	    $lastname = $_POST["lastname"];
	    $gender = $_POST["gender"];
	    $denomination = $_POST["denomination"];
	    $Region = $_POST["Region"];
	    $Rgroup = $_POST["Rgroup"];
	    $District = $_POST["District"];
	    $school = $_POST["school"];
	    $phnumber = $_POST["phnumber"];

    	$query = "UPDATE sregister set firstname='$firstname', lastname='$lastname', gender='$gender', denomination='$denomination', Region='$Region', Rgroup='$Rgroup', District='$District', school='$school', phnumber='$phnumber' where id='$id'";
	    $result = mysqli_query($conn, $query);
	    	// Javascript alert with php and redirect to another page
	    	echo "<script>
				alert('$firstname $lastname registration has been updated successfully');
				window.location.href='sfetch.php';
				</script>";

	    } else{
	    	$id = $_GET['id'];
	    }
			    

			
?>
<!Doctype Html>
<html>
	<head>
		<title>Update Dashboard</title>
		<link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
	</head>
	<body>
		<?php

			$query = "SELECT * from sregister WHERE id='$id'";
  $results = mysqli_query($conn, $query);
        while ($row = mysqli_fetch_assoc($results)) {
           
			    $id = $row["id"];
			    $firstname = $row["firstname"];
			    $lastname = $row["lastname"];
			    $gender = $row["gender"];
			    $denomination = $row["denomination"];
			    $Region = $row["Region"];
			    $Rgroup = $row["Rgroup"];
			    $District = $row["District"];
			    $school = $row["school"];
			    $phnumber = $row["phnumber"];
		?>


	<div class="container">
		<h3>Update State Registration Database</h3>
		<div class="col-md-3">
		</div>

		<div class="col-md-9">
		<form class="form-group" action="update.php" method="POST">
			<input type="hidden" name="id" value="<?php echo $row["id"]; ?>">

			<div >
				<label>Firstname:</label><br>
				<input class="form-control" type="text" name="firstname" value="<?php echo $row['firstname']?>" required/>
			</div>

			<div>
				<label>Lastname:</label><br>
				<input class="form-control" type="text" name="lastname" value="<?php echo $row['lastname']?>" required/>
			</div>

			<div>
				<label>Gender:</label><br>
				<select class="form-control" name="gender">
					<option value="<?php echo $row['gender']?>"><?php echo $row['gender']?></option>
					<option value="Female">Female</option>
					<option value="Male">Male</option>
				</select>
			</div>

			<div>
				<label>Denomination:</label><br>
					<select class="form-control" name="denomination" required>
		<option value="<?php echo $row['denomination']?>"><?php echo $row['denomination']?></option>
        <?php
          $sql2 = mysqli_query(mysqli_connect("localhost", "root", "", "successcamp"), "SELECT * FROM denomination");
          while( $row1 = mysqli_fetch_array($sql2)){
            $den_name = $row1['den_name'];
            echo "<option value='$den_name'>$den_name</option>";
          };
        ?> 
		</select>
			</div>


			<div>
				<label>Region:</label><br>
				<select class="form-control" name="Region">

					<!-- Collect the id and convert it to the name of the region, then echo the name in the first option. Then fetch all the region so a new one can be selected, thereafter, post it the sregister after due conversion   -->
					 <?php
			            $sql11 = "SELECT * FROM region where id = '$Region'";
			            $query22 = mysqli_query($conn, $sql11);
			            $row11 = mysqli_fetch_array($query22);
			            $region_name = $row11['region_name'];
			         	$id = $row11['id'];
			      

			         ?>

					<option value="<?php echo $id; ?>"><?php echo $region_name; ?></option>
					
					<?php
			          $sql2 = mysqli_query(mysqli_connect("localhost", "root", "", "successcamp"), "SELECT * FROM region");
			          while( $row1 = mysqli_fetch_array($sql2)){
			            $region_name = $row1['region_name'];
			            $id = $row1['id'];
			            echo "<option value='$id'>$region_name</option>";
			          };
			        ?> 			        

				</select>
			</div>

			<div>
				<label>Group:</label><br>
				<select class="form-control" name="Rgroup">
					
						 <?php
			            $sq1 = "SELECT * FROM rgroup where id = '$Rgroup'";
			            $quer2 = mysqli_query($conn, $sq1);
			            $ro = mysqli_fetch_array($quer2);
			            $group_name = $ro['group_name'];
			            $id = $ro['id'];
			         ?>

					<option value="<?php echo $id; ?>"><?php echo $group_name; ?></option>
					
			        <?php
			          $sql2 = mysqli_query(mysqli_connect("localhost", "root", "", "successcamp"), "SELECT * FROM rgroup");
			          while( $row1 = mysqli_fetch_array($sql2)){
			            $group_name = $row1['group_name'];
			            $id = $row1['id'];
			            echo "<option value='$id'>$group_name</option>";
			          };
			        ?> 

				</select>
			</div>

			<div>
				<label>District:</label><br>
				<select class="form-control" name="District">
					
						 <?php
			            $sq1 = "SELECT * FROM districts where id = '$District'";
			            $quer2 = mysqli_query($conn, $sq1);
			            $ro = mysqli_fetch_array($quer2);
			            $district_name = $ro['district_name'];
			            $id = $ro['id'];
			         ?>

					<option value="<?php echo $id; ?>"><?php echo $district_name; ?></option>
					
			        <?php
			          $sql2 = mysqli_query(mysqli_connect("localhost", "root", "", "successcamp"), "SELECT * FROM districts");
			          while( $row1 = mysqli_fetch_array($sql2)){
			            $district_name = $row1['district_name'];
			            $id = $row1['id'];
			            echo "<option value='$id'>$district_name</option>";
			          };
			        ?> 

				</select>
			</div>

			<div>
				<label>School:</label><br>
				<input class="form-control" type="text" name="school" value="<?php echo $row['school']?>" />
			</div>
			<div class="form-group">
				<label>Phone Number:</label><br>
				<input class="form-control" type="text" name="phnumber" value="<?php echo $row['phnumber']?>"/>
			</div>

			<!-- Submit button starts here -->
			<div >
				<input class="btn btn-primary" type="submit" name="update" value="Update">
			</div>
			<!-- Submit ends here -->
			<?php }; ?>
		</form>
	</div>
	</div>
	<!-- Footer -->
	
	</body>
</html