<?php
include'connection.php';
include 'secure.php';
// Include user session



$id = $_GET['id'];
$sql = "DELETE FROM sregister WHERE id=$id";
if ($conn->query($sql) === TRUE) {
    // Javascript alert with php and redirect to another page
	    	echo "<script>
				alert('Record deleted successfully');
				window.location.href='sfetch.php';
				</script>";
} else {
    echo "Error deleting record: " . $conn->error;
};
$conn->close();
?>