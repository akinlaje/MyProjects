<div class="container-fluid" style="background-color:#e3f2fd; font-family:times">
		<div style="text-align:center">
			&copy; 2020 <a style='color:red; font-family:times' href="https://davakconsult.com.ng" target="_blank">Davak Consult</a>  For DLBC Benue State
		</div>
	</div>