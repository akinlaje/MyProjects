<?php  

$db_hostname = "localhost";
$db_database = "properti_successcamp";
$db_username = "properti";
$db_password = "2exnEqm__RK-";
$conn= mysqli_connect($db_hostname, $db_username, $db_password, $db_database);
if(mysqli_connect_errno()){
    echo "failed".mysqli_connect_error();
}
?>
