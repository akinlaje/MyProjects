<?php
session_start();
include 'connection.php';

?>

<?php
$msg ="" ;
if(isset($_SESSION['login_users'])){
  $session_type = $_SESSION['login_type'];
  if ($session_type == "admin"){
    header("location:dashboard.php");
  }
  elseif ($session_type == "registrar"){
    header("location:register.php");
  }
  // elseif ($session_type == "student"){
  //   header("location:student.php");
  // }
  else{

   header('index.php');
   $msg = "Username or password is incorrect";
  }
}


// function sec($data) {
//           $data = trim($data);
//           $data = stripslashes($data);
//           $data = htmlspecialchars($data);
//           return $data;
//         };

?>

<?php


if (isset($_POST['login'])) {

        
              $username = mysqli_real_escape_string($conn,$_POST['username']);
              $password = mysqli_real_escape_string($conn,$_POST['password']);
              $query = mysqli_query($conn,"SELECT * FROM login where username = '$username' AND password= '$password'")or die (mysqli_error($conn)); 
              $row = mysqli_fetch_array($query);
              if(!empty($row['username']) AND !empty($row['password']))
              {
               
                $_SESSION['login_users'] = $row['username'];
                $_SESSION['login_type'] = $row['usertype'];
                $usertype = $row['usertype'];
                
                if ($usertype == "admin"){
                  header("location:dashboard.php");
                }
                elseif ($usertype == "registrar"){
                  header("location:register.php");
                }
                //   elseif ($usertype == "student"){
                //     header("location:student.php");
                // }

                     else{
                      // header('location:index.php');
                      $msg = "Username or password is incorrect";
                     }          
              };
  
}
?>
 

<html>
<head>
<title>DLBC Taraba Login Page | Retreat Registration</title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport"    content="width=device-width, initial-scale=1.0">
<meta name="description" content="DCLM Retreat Registration...Achieving Heaven's Goal." />
<meta name="keywords" content="DCLM, DCLM Radio, DCLM Online Radio, Online Radio, Deeperlife Radio, Pastor Kumuyi live, deeperLife, Pastor Kumuyi, Messages, live radio messages, dclm, dclm bible study live" />
     <link rel="apple-touch-icon" sizes="76x76" href="https://radio.dclm.org/assets/img/apple-icon.png">
<link rel="shortcut icon" type="image/png" href="https://radio.dclm.org/assets/img/favicon.png">
  
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/js/bootstrap.min.js">
		<link rel="stylesheet" type="text/css" href="styles.css">
		<script src="assets/vendor/jquery/jquery.min.js"></script>

		<style type="text/css">
			/* BASIC */



		</style>
</head>
<body>


<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->

    <!-- Icon -->
    <div class="fadeIn first">
      <img src="images/dclm-logo.png" id="icon" alt="DCLM Logo" />

    </div>
    <h1>DCLM TARABA</h1>

    <!-- Login Form -->
    <form method="POST" action="index.php">
      <input type="text" id="login" class=" fadeIn second" name="username" placeholder="Username">
      <input type="password" id="password" class="fadeIn third" name="password" placeholder="Password">
      <input type="submit" name="login" class="fadeIn fourth" value="Log In">
    </form>

    <!-- Remind Passowrd -->
    <!--<div id="formFooter">-->
    <!--  <a class="underlineHover" href="register.php">Register</a>-->
    <!--</div>-->

  </div>
</div>

<!-- Footer -->
 
</body>
</html>