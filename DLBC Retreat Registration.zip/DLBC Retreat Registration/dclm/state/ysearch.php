<?php
include "connection.php";
include 'secure.php';
?>
<!Doctype Html>
<html>
	<head>
		<title>DCLM | Search Query Dashboard</title>
		<link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
	         <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/js/bootstrap.min.js">
    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    <style>
    .imgi {
  position: relative;
  text-align: center;
  color: white;
}

/* Centered text */
.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
}

a:hover {
  background-color: red;
  color: white;
  padding: 8px;
  border-radius: 2px
}
</style>
	</head>
	<body>

 <div class="wrapper">
        <!-- Sidebar  -->
       <?php include 'sidebar.php'; ?>
      
	<div class="container">

		<h2>SEARCH RESULT TABLE</h2>
		
			<div class=" col-md-12 text-center">
				<a href="fetch.php" style="color:white"><button class="btn btn-success">Back To Registration Data Table</button></a> 
			</div>
		
			<?php   

$output = '';

//Collect data
if (isset($_POST['submit'])) {
	$name = $_POST['search'];

	$name = preg_replace("#[^0-9a-z]#i", "", $name);

	$query = "SELECT * FROM sregister WHERE section='Youth' && firstname LIKE '%$name%' OR lastname LIKE '%$name%' OR level LIKE '%$name%' LIKE '%$name%'  OR Region LIKE '%$name%' OR District LIKE '%$name%' OR school LIKE '%$name%' OR phnumber LIKE '%$name%' OR denomination LIKE '%$name%' OR gender LIKE '%$name%'";
	$result = mysqli_query($conn, $query);
	$count = mysqli_num_rows($result);
	if($count == 0){
		echo "<script>
        alert('$name was not found');
        window.location.href='sfetch.php';
        </script>";
		$output = 'There was no search result';
		} else{
			
				

	?>
			
			

			
		<table class="table table-responsive table-hover table-bordered">
			<?php echo "<h4 class='search'>You searched for: $name </h4>";?>
			<thead>
				<tr>
					<td>S/N</td>
					<td>Firstname</td>
					<td>Lastname</td>
					<td>Gender</td>
					<td>Address</td>
					<td>Age</td>
					<td>Denomination</td>
					<td>Region</td>
					<td>Group</td>
					<td>District</td>
					<td>School/ Institution</td>
					<td>Phone Number</td>
					<td colspan="2">Action</td>

				</tr>
			</thead>
			<tbody>
				
				

				<?php
		 		
  				function sec($data) {
							  $data = trim($data);
							  $data = stripslashes($data);
							  $data = htmlspecialchars($data);
							  return $data;
							};
				$i=1;
  				while($row = mysqli_fetch_array($result)) {   
  				 $i;      
			     $firstname = sec($row["firstname"]);
          $lastname = sec($row["lastname"]);
          $gender = sec($row["gender"]);
          $address = sec($row["address"]);
          $age = sec($row["age"]);
          $denomination = sec($row["denomination"]);
          $Region = sec($row["Region"]);
          $Rgroup = sec($row["Rgroup"]);
          $District = sec($row["District"]);
          $school = sec($row["school"]);
          $phnumber = sec($row["phnumber"]);

		?>

		 <?php
            $sql11 = "SELECT * FROM region where id = '$Region'";
            $query22 = mysqli_query($conn, $sql11);
            $row11 = mysqli_fetch_array($query22);
            $region_name = $row11['region_name'];
          ?>

           <?php
            $sql1 = "SELECT * FROM rgroup where id = '$Rgroup'";
            $query2 = mysqli_query($conn, $sql1);
            $row1 = mysqli_fetch_array($query2);
            $group_name = $row1['group_name'];
          ?>

           <?php
            $sqla = "SELECT * FROM districts where id = '$District'";
            $querya = mysqli_query($conn, $sqla);
            $rowa = mysqli_fetch_array($querya);
            $district_name = $rowa['district_name'];
          ?>
				<tr>
					
					<td><?php echo $i++; ?></td>
          <td><?php echo $firstname;?></td>
          <td><?php echo $lastname;?></td>
          <td><?php echo $gender;?></td>
          <td><?php echo $address;?></td>
          <td><?php echo $age;?></td>
          <td><?php echo $denomination;?></td>
          <td><?php echo $region_name;  ?></td>
          <td><?php echo $group_name;?></td>
          <td><?php echo $district_name;?></td>
          <td><?php echo $school;?></td>
          <td><?php echo $phnumber;?></td>

					<td class=""><a class="col" href="update.php?id=<?php echo $row['id']; ?>">Update</a></td>
					<td class=""><a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a></td>
				</tr>
				
			</tbody>
		<?php }; ?>
		</table>
<?php }; ?>
	</div>
	<?php }; ?>

	<!-- Footer -->
	 <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
	</body>
</html>