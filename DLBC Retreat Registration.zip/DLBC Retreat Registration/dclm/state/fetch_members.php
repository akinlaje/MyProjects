<?php
include 'connection.php';
include 'secure.php';


?>
<!DOCTYPE html>
<html>
<head>
  <title>DCLM Dashboard | Summary of Registered Participants</title>
  <script src="../jquery.js"></script>
  <link rel="stylesheet" type="text/css" href="../assets/vendor/bootstrap/css/bootstrap.css">
  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>Collapsible sidebar using Bootstrap 4</title>
<!--         <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/js/bootstrap.min.js"> -->
    <!-- Bootstrap CSS CDN -->
    <script src="jquery.js"></script>
    <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../style4.css">

    <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
 
</head>
<body>
  <div class="wrapper">
        <!-- Sidebar  -->
        <?php include 'sidebar1.php'; ?>
      

    
    <h2 style='text-align:center;'>REGISTERED PARTICIPANTS DATA</h2>
    
      <div class=" col-md-12 text-center">
        <form class="form-group" action="search.php" method="POST">
          <input type="text" name="search" class="form-control" placeholder="Type Name, District, Denomination, etc. here to Search" required/><br>
          <input type="submit" class="btn btn-success" value="Search" name="submit" />
        </form>  
      </div>
    

      <div> 
        <button type="button" style="float:right" class="btn btn-sm btn-success pull-right" onclick="print()">Print</button><br>
      </div>
      
    
    <hr>

    <table class="table table-responsive table-hover table-bordered">
      <thead>
        <tr style="text-align:center; text-transform:uppercase">
          <th>S/N</th>
          <th>Firstname</th>
          <th>Lastname</th>
          <th>Gender</th>
          <th>Denomination</th>
          <th>Region</th>
          <th>Group</th>
          <th>District</th>
          <th>School</th>
          <th>Phone Number</th>
          <th colspan="2">Action</th>

        </tr>
      </thead>
      <tbody>


        <?php

        function sec($data) {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
                return $data;
              };

     $query = "SELECT * from sregister where denomination ='Deeper Life Bible Church' ORDER BY id ASC";
        $results = mysqli_query($conn, $query);
        // The starting point of the iteration
        $i=1;
        // While statement 
        while ($row = mysqli_fetch_assoc($results)) {

              $i;
          $firstname = sec($row["firstname"]);
          $lastname = sec($row["lastname"]);
          $gender = sec($row["gender"]);
          $denomination = sec($row["denomination"]);
          $Region = sec($row["Region"]);
          $Rgroup = sec($row["Rgroup"]);
          $District = sec($row["District"]);
          $school = sec($row["school"]);
          $phnumber = sec($row["phnumber"]);

          
          
         
    ?>
          <?php
            $sql11 = "SELECT * FROM region where id = '$Region'";
            $query22 = mysqli_query($conn, $sql11);
            $row11 = mysqli_fetch_array($query22);
            $region_name = $row11['region_name'];
          ?>

           <?php
            $sql1 = "SELECT * FROM rgroup where id = '$Rgroup'";
            $query2 = mysqli_query($conn, $sql1);
            $row1 = mysqli_fetch_array($query2);
            $group_name = $row1['group_name'];
          ?>

           <?php
            $sqla = "SELECT * FROM districts where id = '$District'";
            $querya = mysqli_query($conn, $sqla);
            $rowa = mysqli_fetch_array($querya);
            $district_name = $rowa['district_name'];
          ?>
   
        <tr>
          <!-- The $i++ increases the value by +1 -->
          <td><?php echo $i++; ?></td>
          <td><?php echo $firstname;?></td>
          <td><?php echo $lastname;?></td>
          <td><?php echo $gender;?></td>
          <td><?php echo $denomination;?></td>
          <td><?php echo $region_name;  ?></td>
          <td><?php echo $group_name;?></td>
          <td><?php echo $district_name;?></td>
          <td><?php echo $school;?></td>
          <td><?php echo $phnumber;?></td>
          <td class=""><a href="update.php?id=<?php echo $row["id"]; ?>">Update</a></td>
          <td class=""><a href="delete.php?id=<?php echo $row['id'];?>">Delete</a></td>
        </tr>
        <?php }; ?>
      </tbody>
    </table>

    </div>
    
  </div>
</div>

</div>
</div>
   
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>
</html> 