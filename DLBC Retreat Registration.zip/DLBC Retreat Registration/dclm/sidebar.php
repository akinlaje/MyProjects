<div class="panel">Navigation Panel</div>
		<div>
			<a href="fetch.php" style='padding:10px; '><button class='btn btn-secondary'>View Registered Participants</button></a>
			<a href="count.php" style='padding:10px; '><button class='btn btn-secondary'>Attendance</button></a>
			<a href="convertsreg.php" style='padding:10px; '><button class='btn btn-secondary'>Register Convert</button></a>
			<a href="fetchconverts.php" style='padding:10px; '><button class='btn btn-secondary'>View Converts</button></a>

		</div><br>
		<img class="img-fluid" src="assets/img/sidebg.gif">