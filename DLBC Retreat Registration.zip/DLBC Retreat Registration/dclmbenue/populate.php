<?php
include 'connection.php';
include 'secure.php';
?>
<?php
if (isset($_POST['region'])) {
	$region_name = $_POST['region_name'];

	// Test for duplicate entry
	$sql = "SELECT * FROM region WHERE region_name = '$_POST[region_name]'";
	$result = mysqli_query($conn, $sql);
	

	if(mysqli_num_rows($result) > 0)
    
{

	echo "<script>
				alert('$region_name is already registered');
				window.location.href='populate.php';
				</script>";

 }
 else{
	$reg = "INSERT INTO region (region_name) VALUES('$region_name')";
	$sql1 = mysqli_query($conn, $reg);

 }
 };





// District input starts here
if (isset($_POST['district'])) {
	$region_id = $_POST['region_id'];
	$group_id = $_POST['group_id'];
	$district_name = $_POST['district_name'];

    	// Test for duplicate entry
	$sql = "SELECT * FROM districts WHERE district_name = '$_POST[district_name]'";
	$result = mysqli_query($conn, $sql);
	

	if(mysqli_num_rows($result) > 0)
    
{

	echo "<script>
				alert('$district_name is already registered');
				window.location.href='populate.php';
				</script>";

 }
 else{
	$dist = "INSERT INTO districts (region_id, group_id ,district_name) VALUES('$region_id', '$group_id', '$district_name')";
	$sql2 = mysqli_query($conn, $dist);
	

 }
 };

if (isset($_POST['denomination'])) {
	$den_name = $_POST['den_name'];
    
    	// Test for duplicate entry
	$sql = "SELECT * FROM denomination WHERE den_name = '$_POST[den_name]'";
	$result = mysqli_query($conn, $sql);
	

	if(mysqli_num_rows($result) > 0)
    
{

	echo "<script>
				alert('$den_name is already registered');
				window.location.href='populate.php';
				</script>";

 }
 else{
	$den = "INSERT INTO denomination (den_name) VALUES('$den_name')";
	$sql3 = mysqli_query($conn, $den);
	
}
};
?>

<!-- Group insert starts here -->
<?php

if (isset($_POST['grpin'])) {
	$group_name = $_POST['group_name'];
	$region_id = $_POST['region_id'];
	
    	// Test for duplicate entry
	$sql = "SELECT * FROM rgroup WHERE group_name = '$_POST[group_name]'";
	$result = mysqli_query($conn, $sql);
	

	if(mysqli_num_rows($result) > 0)
    
{

	echo "<script>
				alert('$group_name is already registered');
				window.location.href='populate.php';
				</script>";

 }
 else{

	$ent = mysqli_query($conn, "INSERT INTO rgroup (group_name, region_id) VALUES('$group_name', '$region_id')");
	var_dump($ent);

 
 }
 };
?>

<!DOCTYPE html>
<html>
<head>
	<title>DCLM Registration | Populate Region, Group and District</title>
	    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../style4.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
   <style >
   		 #body-row {
        margin-left: 0;
        margin-right: 0;
    }

    #sidebar-container {
        min-height: 100vh;
        background-color: #132644;
        padding: 0;
        /* flex: unset; */
    }
    
    .sidebar-expanded {
        width: 230px;
    }
    
    .sidebar-collapsed {
        /*width: 60px;*/
        width: 100px;
    }

    /* ----------| Menu item*/    
    #sidebar-container .list-group a {
        height: 50px;
        color: white;
    }

    /* ----------| Submenu item*/    
    #sidebar-container .list-group li.list-group-item {
        background-color: #132644;
    }
    
    #sidebar-container .list-group .sidebar-submenu a {
        height: 45px;
        padding-left: 30px;
    }
    
    .sidebar-submenu {
        font-size: 0.9rem;
    }

    /* ----------| Separators */    
    .sidebar-separator-title {
        background-color: #132644;
        height: 35px;
    }
    
    .sidebar-separator {
        background-color: #132644;
        height: 25px;
    }
    
    .logo-separator {
        background-color: #132644;
        height: 60px;
    }
    
    a.bg-dark {
        background-color: #132644 !important;
    }
	</style>

	<script >
		// Hide submenus
$('#body-row .collapse').collapse('hide'); 

// Collapse/Expand icon
$('#collapse-icon').addClass('fa-angle-double-left'); 

// Collapse click
$('[data-toggle=sidebar-colapse]').click(function() {
    SidebarCollapse();
});

function SidebarCollapse () {
    $('.menu-collapsed').toggleClass('d-none');
    $('.sidebar-submenu').toggleClass('d-none');
    $('.submenu-icon').toggleClass('d-none');
    $('#sidebar-container').toggleClass('sidebar-expanded sidebar-collapsed');
    
    // Treating d-flex/d-none on separators with title
    var SeparatorTitle = $('.sidebar-separator-title');
    if ( SeparatorTitle.hasClass('d-flex') ) {
        SeparatorTitle.removeClass('d-flex');
    } else {
        SeparatorTitle.addClass('d-flex');
    }
    
    // Collapse/Expand icon
    $('#collapse-icon').toggleClass('fa-angle-double-left fa-angle-double-right');
}
	</script>
</head>


<body >
	  <div class="wrapper">
        <!-- Sidebar  -->
      <?php include 'sidebar.php'; ?>

	<div class="container "><h3 class="text-center text-light bg-primary p-3 mt-2">Region, Group, &AMP; District Registration Dashboard</h3>
	<div class="row justify-content-center">

		<div class=" col-lg-3 bg-light mt-5 m-4 px-0" style="border:2px solid blue;">
			<h3 class="text-center text-light bg-primary p-3">REGION</h3>
			<form action="populate.php" method="POST" class="p-4">
				<div class="form-group">
					<input type="text" class="form-control form-control-lg" placeholder="Region name" name="region_name" required/>
				</div>
				
				<input type="submit" name="region" class="btn btn-primary btn-block" value="Register Region">
			
			</form>
		</div>


		<div class="col-lg-3 bg-light mt-5 m-4 px-0" style="border:2px solid blue;">
			<h3 class="text-center text-light bg-primary p-3">Group</h3>
			<form action="populate.php" method="POST" class="p-4">
				<div class="form-group">
				<select name="region_id" class="region form-control">
			        <option selected="selected">Select Region</option>
			        <?php
			          $sql = mysqli_query($conn, "SELECT * from region order by region_name ");


			          while ($row = mysqli_fetch_array($sql)) {
			           ?>
			           <option value="<?php echo $row['id']; ?>">
			            <?php echo $row['region_name']; ?></option>
			        <?php
			          }
			        ?>
      			</select>
				</div>
				<div class="form-group">
					<input type="text" class="form-control form-control-lg" placeholder="Group name" name="group_name" required/>
				</div>
				
				<input type="submit" name="grpin" class="btn btn-primary btn-block" value="Register Group">
			
			</form>
		</div>

<!-- 
		<div class="col-lg-3 bg-light mt-5 m-4 px-0">
			<h3 class="text-center text-light bg-primary p-3">GROUP</h3>
			<form action="populate.php" method="POST" class="p-4">
				<div class="form-group">
					<input type="text" class="form-control form-control-lg" placeholder="Name of Group" name="group_name" required/>
				</div>
				
				<input type="submit" name="grpin" class="btn btn-primary btn-block" value="Register District">
			
			</form>
		</div>


 -->

 		<div class="col-lg-3 bg-light mt-5 m-4 px-0" style="border:2px solid blue;">
			<h3 class="text-center text-light bg-primary p-3">DISTRICT</h3>
			<form action="populate.php" method="POST" class="p-4">
				<div class="form-group">
				<select name="region_id" class="region form-control">
			        <option selected="selected">Select Region</option>
			        <?php
			          $sql = mysqli_query($conn, "SELECT * from region order by region_name ");


			          while ($row = mysqli_fetch_array($sql)) {
			           ?>
			           <option value="<?php echo $row['id']; ?>">
			            <?php echo $row['region_name']; ?></option>
			        <?php
			          }
			        ?>
      			</select>
				</div>

				<div class="form-group">
				<select name="group_id" class="region form-control">
			        <option selected="selected">Select Group</option>
			        <?php
			          $sql = mysqli_query($conn, "SELECT * from rgroup order by group_name ");


			          while ($row = mysqli_fetch_array($sql)) {
			           ?>
			           <option value="<?php echo $row['id']; ?>">
			            <?php echo $row['group_name']; ?></option>
			        <?php
			          }
			        ?>
      			</select>
				</div>

				<div class="form-group">
					<input type="text" class="form-control form-control-lg" placeholder="Name of district" name="district_name" required/>
				</div>
				
				<input type="submit" name="district" class="btn btn-primary btn-block" value="Register District">
			
			</form>
		</div>
	</div>

	<div class="row justify-content-center">
		<div class="col-lg-3 bg-light mt-5 m-4 px-0" style="border:2px solid blue;">
			<h3 class="text-center text-light bg-primary p-3">DENOMINATION</h3>
			<form action="populate.php" method="POST" class="p-4">
				<div class="form-group">
					<input type="text" class="form-control form-control-lg" placeholder="Name of denomination" name="den_name" required/>
				</div>
				
				<input type="submit" name="denomination" class="btn btn-primary btn-block" value="Register Denomination">
			
			</form>
		</div>
	</div>
</div>

<?php include'footer.php' ?>
 <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>
</html>