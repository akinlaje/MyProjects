<?php
include'connection.php';
include'secure.php';
if (isset($_POST['submit'])) {
  $fullname = $_POST['fullname'];
  $username = $_POST['username'];
  $password = $_POST['password'];
  $usertype = $_POST['usertype'];

  $sql1 = "SELECT * FROM login WHERE username = '$_POST[username]' && fullname = '$_POST[fullname]'";
  $result = mysqli_query($conn, $sql1);
  

if(mysqli_num_rows($result) > 0)
    
{

  echo "<script>
        alert('Failed to register, $fullname $username already exist');
        window.location.href='user_reg.php';
        </script>";

 }
else{

  $sql = "INSERT INTO login (fullname, username, password, usertype) VALUES('$fullname', '$username', '$password', '$usertype')";
  $query = mysqli_query($conn, $sql);

     echo "<script>
        alert('$fullname registration as $usertype is successful');
        window.location.href='user_reg.php';
        </script>";
};
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>DCLM Taraba State | Register Users</title>
    <meta name="viewport"    content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
<!--         <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/js/bootstrap.min.js"> -->
    <!-- Bootstrap CSS CDN -->
    <script src="../jquery.js"></script>
    <link rel="stylesheet" href="../font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../style4.css">

    <link rel="stylesheet" type="text/css" href="assets/vendor/bootstrap/css/bootstrap.css">
    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>
</head>
<body>
  <div class="wrapper">
        <!-- Sidebar  -->
       <?php include 'sidebar.php'; ?>
      

<div class="container mt-4">
<div class="offset-3 col-md-6">
 
    <div class="alert alert-success">
       
    </div>


  <div class="card">
    <div class="card-header text-center font-weight-bold">
      DCLM Taraba - Register Users Panel
    </div>
    <div class="card-body">
      <form name="add-blog-post-form" id="add-blog-post-form" method="post" action="#">
       

         <div class="form-group">
                  <label for="exampleInputEmail1">Full Name</label>
                  <input type="text" name="fullname" class="form-control"  >
                 
          </div>

          <div class="form-group">
                  <label for="exampleInputEmail1">Username</label>
                  <input type="text" name="username" class="form-control"  >
                 
          </div>


           <div class="form-group">
                  <label for="exampleInputEmail1">Password</label>
                  <input type="password" name="password" class="form-control"  >
                 
            </div>

             <div class="form-group">
                  <label for="exampleInputEmail1">User Type</label>
                  <select class="form-control" name="usertype">
                    <option class="form-control" value="admin">Admin</option>
                    <option class="form-control" value="registrar">Registrar</option>
                  </select>
                  
                 
            </div>

        <button type="submit" class="btn btn-primary" name="submit">Submit</button>
      </form>
    </div>
  </div>
</div>
</div>   


 <!-- Popper.JS -->
    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>
</html>