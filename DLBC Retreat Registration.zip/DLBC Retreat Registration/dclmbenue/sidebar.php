 <nav id="sidebar" style="background: rgb(2,0,36);
background: linear-gradient(90deg, rgba(2,0,36,1) 0%, rgba(9,9,121,1) 35%, rgba(0,212,255,1) 100%);">
            <div class="sidebar-header">
                <h3>DCLM Benue </h3>
                <strong>DB</strong>
            </div>

            <ul class="list-unstyled components">
                <li class="active"><!--  -->
                    <a href="dashboard.php"  aria-expanded="false">
                        <i class="fas fa-home"></i>
                        Dashboard
                    </a>
                   <!--  <ul class="collapse list-unstyled" id="homeSubmenu">
                        <li>
                            <a href="#">View all registered members</a>
                        </li>
                        <li>
                            <a href="#">View registration by region</a>
                        </li>
                        <li>
                            <a href="#">View registration by group</a>
                        </li>
                    </ul> -->
                </li>
                <li>
                    <a href="populate.php">
                       <i class="fa fa-compass" aria-hidden="true"></i>

                        Create Locations
                    </a>
                   <!--  <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle">
                        <i class="fas fa-copy"></i>
                        Pages
                    </a>
                    <ul class="collapse list-unstyled" id="pageSubmenu">
                        <li>
                            <a href="#">Page 1</a>
                        </li>
                        <li>
                            <a href="#">Page 2</a>
                        </li>
                        <li>
                            <a href="#">Page 3</a>
                        </li>
                    </ul> -->
                </li>
                <li>
                    <a href="sregister.php">
                        <i class="fa fa-book" aria-hidden="true"></i>

                        Register Participant
                    </a>
                </li>
                  <li>
                    <a href="sconvert_registration.php">
                        <i class="fa fa-book" aria-hidden="true"></i>

                        Register Convert
                    </a>
                </li>
                 <li>
                    <a href="sfetch.php">
                        <i class="fa fa-book" aria-hidden="true"></i>

                        Registered Participants
                    </a>
                </li>
                 <li>
                    <a href="scon_fetch.php">
                        <i class="fa fa-users" aria-hidden="true"></i>

                         Registered Converts
                    </a>
                </li>
                <li>
                    <a href="sfetch_members.php">
                        <i class="fa fa-users" aria-hidden="true"></i>

                        Members Database
                    </a>
                </li>
                 <li>
                    <a href="sfetch_invitee.php">
                        <i class="fa fa-users" aria-hidden="true"></i>

                        Invitees Database
                    </a>
                </li>
                <li>
                    <a href="user_reg.php">
                        <i class="fa fa-book" aria-hidden="true"></i>

                        Create Users
                    </a>
                </li>
                <!-- <li>
                    <a href="#">
                        <i class="fas fa-paper-plane"></i>
                        Contact
                    </a>
                </li> -->
            </ul>

            
        </nav>

        <!-- Page Content  -->
        <div id="content">

            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <div class="container-fluid">

                    <button type="button" id="sidebarCollapse" class="btn btn-info">
                        <i class="fas fa-align-left"></i>
                        <span></span>
                    </button>
                    <button class="btn btn-dark d-inline-block d-lg-none ml-auto" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-align-justify"></i>
                    </button>

                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="nav navbar-nav ml-auto">
                            <li class="nav-item active" style="border-right: 2px solid blue ">
                                <a class="nav-link" href="#"><?php
echo"<span>Welcome</span>".' '.$_SESSION['login_users'];
?> </a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="logout.php">Logout</a>
                            </li>
                            
                        </ul>
                    </div>
                </div>
            </nav>